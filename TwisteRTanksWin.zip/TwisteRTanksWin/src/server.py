import socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('', 9265))
clients = []
print('Start Server')


while 1:
    try:
        data, addres = sock.recvfrom(1024)
        if data.decode() == "disconnect":
            del clients[clients.index(addres)]
            continue
        elif data.decode(
        ) == "get_online":
            sock.sendto(str(len(clients)).encode(), addres)
            continue
    except Exception as err:
        print(err)

    if addres not in clients:
        clients.append(addres)
    for client in clients:
        if client == addres:
            continue
        # print("Send to :", data, client)
        sock.sendto(data, client)

